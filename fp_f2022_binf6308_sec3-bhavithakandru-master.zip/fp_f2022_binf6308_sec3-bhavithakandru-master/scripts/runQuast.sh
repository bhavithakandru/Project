#!/usr/bin/env bash
# runQuast.sh

function Quast {
    quast.py cholerae/contigs.fasta
}

Quast