#!/usr/bin/env bash
# get_RNA_NGS.sh
# Retrieve the MiSeq Vibrio cholerae NGS reads.
fasterq-dump --split-3 SRR19237527
