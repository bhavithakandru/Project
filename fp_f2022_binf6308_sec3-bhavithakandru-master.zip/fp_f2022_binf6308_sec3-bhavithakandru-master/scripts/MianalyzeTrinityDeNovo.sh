#!/usr/bin/env bash
#MianalyzeTrinity.sh
# Usage: bash scripts/analyzeTrinity.sh 1>results/trinity_de_novo_stats.txt 2>results/logs/analyzeTrinity.err

../results/trinity_de_novo/Trinity.fasta

